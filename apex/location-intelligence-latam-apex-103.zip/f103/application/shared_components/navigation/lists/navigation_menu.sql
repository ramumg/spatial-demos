prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(234284189737962647)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
,p_version_scn=>'SH256:QV2JuI4ToR2YGIHswIprIxNDetl_uF3eryJNy4GJQ_g'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(117675741599840605)
,p_list_item_display_sequence=>65
,p_list_item_link_text=>'Ask the Map'
,p_static_id=>'ask-the-map'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-comments-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234301824517020582)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Near Me'
,p_static_id=>'cerca-de-mi'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-compass'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234683464631878095)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Regional Coverage'
,p_static_id=>'cobertura-regional'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(117675741598840605)
,p_list_item_display_sequence=>55
,p_list_item_link_text=>'Coverage Gaps'
,p_static_id=>'coverage-gaps'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234692757896016837)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Geocoding'
,p_static_id=>unistr('geocodificaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-location-arrow'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234295312914962731)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234312385059070411)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Locations Map'
,p_static_id=>'mapa-de-ubicaciones'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(235657886850764354)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Distribution Routes'
,p_static_id=>unistr('rutas-de-distribuci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(245058805092469361)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'test_2'
,p_static_id=>'test-2'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(243459076438584999)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'test1'
,p_static_id=>'test1'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp.component_end;
end;
/
