prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(234284946170962674)
,p_name=>'Navigation Bar'
,p_static_id=>'navigation-bar'
,p_version_scn=>'SH256:ZhqIV3m4idEqVdfi3yB17C0NEH--e1hhaMH5Km6rYyg'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234297966067962752)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&APP_USER.'
,p_static_id=>'app-user'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(117675741609840605)
,p_list_item_display_sequence=>36
,p_list_item_link_text=>unistr('Espa\00F1ol')
,p_static_id=>'espanol-home'
,p_list_item_link_target=>'f?p=100:1:&SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-language'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'1,2,3,4,5,6'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(117675741608840605)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>unistr('Espa\00F1ol')
,p_static_id=>'espanol-same-page'
,p_list_item_link_target=>'f?p=100:&APP_PAGE_ID.:&SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-language'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_IN_CONDITION'
,p_list_item_disp_condition=>'1,2,3,4,5,6'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234298526081962754)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_static_id=>'list_item'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(234297966067962752)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234699127838355493)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Reset Demo'
,p_static_id=>'reiniciar-demo'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.:RESET_APP:&DEBUG.:APP:::'
,p_list_item_icon=>'fa-undo'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(234299028229962755)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Sign Out'
,p_static_id=>'sign-out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(234297966067962752)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
