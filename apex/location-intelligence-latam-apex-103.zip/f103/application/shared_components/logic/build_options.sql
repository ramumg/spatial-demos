prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(234282954945962639)
,p_build_option_name=>'Commented Out'
,p_static_id=>'commented-out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'SH256:1lQI3DW9n-0ZEGoDXUirkaB0JWCIATVWpJZCTCkODmI'
);
wwv_flow_imp.component_end;
end;
/
