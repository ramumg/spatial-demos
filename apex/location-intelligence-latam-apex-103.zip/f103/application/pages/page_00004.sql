prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Near Me'
,p_alias=>'NEAR-ME'
,p_step_title=>'Near Me'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234302237504020584)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(234283698800962642)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(117675741988840605)
,p_name=>'Nearest 3 Hubs (SDO_NN)'
,p_static_id=>'nearest-hubs'
,p_template=>4073835273271169698
,p_display_sequence=>30
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select h.location_name as hub,',
' case h.category when ''CENTRO_DISTRIBUCION'' then ''Distribution Center''',
' when ''CENTRO_SERVICIO'' then ''Service Center'' end as hub_type,',
' h.city_name || '', '' || h.country_name as city_country,',
' round(sdo_nn_distance(1), 1) as distance_km',
'from laouc_locations h, laouc_locations o',
'where o.location_id = :P4_ORIGEN_ID',
' and h.category in (''CENTRO_DISTRIBUCION'', ''CENTRO_SERVICIO'')',
' and h.location_id <> o.location_id',
' and sdo_nn(h.geom, o.geom, ''sdo_batch_size=10 unit=KM'', 1) = ''TRUE''',
'order by distance_km',
'fetch first 3 rows only'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P4_ORIGEN_ID'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Select an origin location to find its 3 nearest hubs.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675741991840605)
,p_query_column_id=>3
,p_column_alias=>'CITY_COUNTRY'
,p_column_display_sequence=>30
,p_column_heading=>'City, Country'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675741992840605)
,p_query_column_id=>4
,p_column_alias=>'DISTANCE_KM'
,p_column_display_sequence=>40
,p_column_heading=>'Distance (km)'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675741989840605)
,p_query_column_id=>1
,p_column_alias=>'HUB'
,p_column_display_sequence=>10
,p_column_heading=>'Hub'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675741990840605)
,p_query_column_id=>2
,p_column_alias=>'HUB_TYPE'
,p_column_display_sequence=>20
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234305536334035519)
,p_plug_name=>'Search Parameters'
,p_static_id=>'parametros-de-busqueda'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(234306060126035524)
,p_name=>'Nearby Locations'
,p_static_id=>'ubicaciones-cercanas'
,p_template=>4073835273271169698
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with todas_las_ubicaciones as (',
'    select location_id as id,',
'           location_name,',
'           category,',
'           city_name,',
'           country_name,',
'           geom',
'    from laouc_locations',
'',
'    union all',
'',
'    select -request_id as id,',
'           location_name,',
' ''GEOCODED'' as category,',
'           city_name,',
'           country_name,',
'           gc_geometry as geom',
'    from laouc_geocode_requests',
'    where geocode_status = ''GEOCODIFICADA''',
'),',
'origen as (',
'    select location_id,',
'           geom',
'    from laouc_locations',
'    where location_id = :P4_ORIGEN_ID',
')',
'select *',
'from (',
'    select l.location_name as ubicacion,',
'           initcap(replace(l.category, ''_'', '' '')) as tipo,',
'           l.city_name || '', '' || l.country_name as ciudad_pais,',
'           round(',
'               sdo_geom.sdo_distance(o.geom, l.geom, 0.005, ''unit=KM''),',
'               2',
'           ) as distancia_km',
'    from origen o',
'    join todas_las_ubicaciones l',
'      on l.id <> o.location_id',
')',
'where distancia_km <= :P4_RADIUS_KM',
'order by distancia_km'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P4_ORIGEN_ID,P4_RADIUS_KM'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234306989688035533)
,p_query_column_id=>3
,p_column_alias=>'CIUDAD_PAIS'
,p_column_display_sequence=>30
,p_column_heading=>'City, Country'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234307014671035534)
,p_query_column_id=>4
,p_column_alias=>'DISTANCIA_KM'
,p_column_display_sequence=>40
,p_column_heading=>'Distance (km)'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234306839494035532)
,p_query_column_id=>2
,p_column_alias=>'TIPO'
,p_column_display_sequence=>20
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234306808111035531)
,p_query_column_id=>1
,p_column_alias=>'UBICACION'
,p_column_display_sequence=>10
,p_column_heading=>'Location'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(234305960116035523)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(234305536334035519)
,p_button_name=>'SEARCH'
,p_static_id=>'search'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234305702138035520)
,p_name=>'P4_ORIGEN_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(234305536334035519)
,p_prompt=>'Origin Location'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select location_name || '' \2014 '' || city_name || '', '' || country_name d,'),
'       location_id r',
'from laouc_locations',
'order by country_name, city_name, location_name'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select a location --'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234305753417035521)
,p_name=>'P4_RADIUS_KM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(234305536334035519)
,p_item_default=>'10'
,p_prompt=>'Radius (km)'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '500',
  'min_value', '1',
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp.component_end;
end;
/
