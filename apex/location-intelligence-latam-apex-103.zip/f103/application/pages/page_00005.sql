prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Regional Coverage'
,p_alias=>'REGIONAL-COVERAGE'
,p_step_title=>'Regional Coverage'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234683770715878140)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(234283698800962642)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234684554641878274)
,p_plug_name=>'Regional Coverage'
,p_static_id=>'cobertura-regional'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(234684613737878274)
,p_region_id=>wwv_flow_imp.id(234684554641878274)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234684751373878274)
,p_map_region_id=>wwv_flow_imp.id(234684613737878274)
,p_name=>'Regional Coverage'
,p_static_id=>'cobertura-regional'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'LAOUC_REGIONS'
,p_include_rowid_column=>false
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_stroke_color=>'#0b4f8a'
,p_stroke_width_subst=>'3'
,p_fill_color=>'#3a86d4'
,p_fill_color_is_spectrum=>false
,p_fill_opacity_subst=>'.45'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'REGION_NAME'
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234700933011371327)
,p_map_region_id=>wwv_flow_imp.id(234684613737878274)
,p_name=>'Geocoded Locations'
,p_static_id=>'new'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select request_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       street_address,',
'       latitude,',
'       longitude',
'from laouc_geocode_requests',
'where geocode_status = ''GEOCODIFICADA'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'REQUEST_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&LOCATION_NAME.<br>&STREET_ADDRESS.<br>',
'&CITY_NAME., &COUNTRY_NAME.'))
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(991005000000001)
,p_map_region_id=>wwv_flow_imp.id(234684613737878274)
,p_name=>'Zone Centers'
,p_static_id=>'zone-centers'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select region_id, region_name, sdo_geom.sdo_centroid(geom, 0.005) as geom from laouc_regions'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'REGION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#0b4f8a'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'1.6'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'REGION_NAME'
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(234307485191035538)
,p_name=>'Coverage Summary'
,p_static_id=>'resumen-de-cobertura'
,p_parent_plug_id=>wwv_flow_imp.id(234684554641878274)
,p_template=>4073835273271169698
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with todas_las_ubicaciones as (',
'    select geom',
'    from laouc_locations',
'',
'    union all',
'',
'    select gc_geometry as geom',
'    from laouc_geocode_requests',
'    where geocode_status = ''GEOCODIFICADA''',
')',
'select r.country_name as pais,',
'       r.city_name as ciudad,',
'       r.region_name as zona_operativa,',
'       count(u.geom) as ubicaciones_cubiertas',
'from laouc_regions r',
'left join todas_las_ubicaciones u',
'    on sdo_anyinteract(r.geom, u.geom) = ''TRUE''',
'group by r.country_name,',
'         r.city_name,',
'         r.region_name',
'order by r.country_name,',
'         r.city_name'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234307700670035540)
,p_query_column_id=>2
,p_column_alias=>'CIUDAD'
,p_column_display_sequence=>20
,p_column_heading=>'City'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234307595930035539)
,p_query_column_id=>1
,p_column_alias=>'PAIS'
,p_column_display_sequence=>10
,p_column_heading=>'Country'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234307850505035542)
,p_query_column_id=>4
,p_column_alias=>'UBICACIONES_CUBIERTAS'
,p_column_display_sequence=>40
,p_column_heading=>'Covered Locations'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234307799467035541)
,p_query_column_id=>3
,p_column_alias=>'ZONA_OPERATIVA'
,p_column_display_sequence=>30
,p_column_heading=>'Operational Zone'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
