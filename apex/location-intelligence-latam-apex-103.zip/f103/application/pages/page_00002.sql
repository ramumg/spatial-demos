prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Locations Map'
,p_alias=>'LOCATIONS-MAP'
,p_step_title=>'Locations Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234312731630070412)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(234283698800962642)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234305292675035516)
,p_plug_name=>'Operations Filters'
,p_static_id=>'filtros-de-operacion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234313541402070547)
,p_plug_name=>'Locations Map'
,p_static_id=>'mapa-de-ubicaciones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(234313677124070547)
,p_region_id=>wwv_flow_imp.id(234313541402070547)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(130285674475987201)
,p_map_region_id=>wwv_flow_imp.id(234313677124070547)
,p_name=>'Branches'
,p_static_id=>'branches'
,p_layer_type=>'POINT'
,p_display_sequence=>11
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    location_id,',
'    location_name,',
'    category,',
'    ''Branch'' as site_type,',
'    country_name,',
'    city_name,',
'    street_address,',
'    operational_status,',
'    geom',
'from laouc_locations',
'where category = ''SUCURSAL''',
'  and (:P2_COUNTRY is null or country_name = :P2_COUNTRY)',
'  and (:P2_CITY is null or city_name = :P2_CITY)',
'  and (:P2_CATEGORY is null or category = :P2_CATEGORY)',
'  and (:P2_STATUS is null or operational_status = :P2_STATUS)'))
,p_items_to_submit=>'P2_COUNTRY,P2_CITY,P2_CATEGORY,P2_STATUS'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#B8860B'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(130290609313987001)
,p_map_region_id=>wwv_flow_imp.id(234313677124070547)
,p_name=>'Clients'
,p_static_id=>'clients'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    location_id,',
'    location_name,',
'    category,',
'    ''Client'' as site_type,',
'    country_name,',
'    city_name,',
'    street_address,',
'    operational_status,',
'    geom',
'from laouc_locations',
'where category = ''CLIENTE''',
'  and (:P2_COUNTRY is null or country_name = :P2_COUNTRY)',
'  and (:P2_CITY is null or city_name = :P2_CITY)',
'  and (:P2_CATEGORY is null or category = :P2_CATEGORY)',
'  and (:P2_STATUS is null or operational_status = :P2_STATUS)'))
,p_items_to_submit=>'P2_COUNTRY,P2_CITY,P2_CATEGORY,P2_STATUS'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#1E88E5'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234313774279070547)
,p_map_region_id=>wwv_flow_imp.id(234313677124070547)
,p_name=>'Distribution Centers'
,p_static_id=>'mapa-de-ubicaciones'
,p_layer_type=>'POINT'
,p_display_sequence=>13
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    location_id,',
'    location_name,',
'    category,',
'    ''Distribution center'' as site_type,',
'    country_name,',
'    city_name,',
'    street_address,',
'    operational_status,',
'    geom',
'from laouc_locations',
'where category = ''CENTRO_DISTRIBUCION''',
'  and (:P2_COUNTRY is null or country_name = :P2_COUNTRY)',
'  and (:P2_CITY is null or city_name = :P2_CITY)',
'  and (:P2_CATEGORY is null or category = :P2_CATEGORY)',
'  and (:P2_STATUS is null or operational_status = :P2_STATUS)'))
,p_items_to_submit=>'P2_COUNTRY,P2_CITY,P2_CATEGORY,P2_STATUS'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#2E7D32'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(85885827377788702)
,p_map_region_id=>wwv_flow_imp.id(234313677124070547)
,p_name=>'Service Centers'
,p_static_id=>'service-centers'
,p_layer_type=>'POINT'
,p_display_sequence=>12
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    location_id,',
'    location_name,',
'    category,',
'    ''Service center'' as site_type,',
'    country_name,',
'    city_name,',
'    street_address,',
'    operational_status,',
'    geom',
'from laouc_locations',
'where category = ''CENTRO_SERVICIO''',
'  and (:P2_COUNTRY is null or country_name = :P2_COUNTRY)',
'  and (:P2_CITY is null or city_name = :P2_CITY)',
'  and (:P2_CATEGORY is null or category = :P2_CATEGORY)',
'  and (:P2_STATUS is null or operational_status = :P2_STATUS)'))
,p_items_to_submit=>'P2_COUNTRY,P2_CITY,P2_CATEGORY,P2_STATUS'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#7B1FA2'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234309677251035560)
,p_map_region_id=>wwv_flow_imp.id(234313677124070547)
,p_name=>'Geocoded Locations'
,p_static_id=>'ubicaciones-geocodificadas'
,p_layer_type=>'POINT'
,p_display_sequence=>50
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    request_id,',
'    location_name,',
'    country_name,',
'    city_name,',
'    street_address,',
'    latitude,',
'    longitude,',
'    geocode_status,',
'    gc_geometry as geom',
'from laouc_geocode_requests',
'where geocode_status = ''GEOCODIFICADA'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'REQUEST_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#ef6000'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
'&STREET_ADDRESS.<br>',
'&CITY_NAME., &COUNTRY_NAME.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234305073096035514)
,p_name=>'P2_CATEGORY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(234305292675035516)
,p_prompt=>'All Types'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(replace(category, ''_'', '' '')) d, category r',
'from (',
'  select distinct category',
'  from laouc_locations',
')',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234304964613035513)
,p_name=>'P2_CITY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(234305292675035516)
,p_prompt=>'All Cities'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select city_name d, city_name r',
'from (',
'  select distinct city_name',
'  from laouc_locations',
'  where :P2_COUNTRY is null',
'     or country_name = :P2_COUNTRY',
')',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234304850631035512)
,p_name=>'P2_COUNTRY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(234305292675035516)
,p_prompt=>'All Countries'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select country_name d, country_name r',
'from (',
'  select distinct country_name',
'  from laouc_locations',
')',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234305122367035515)
,p_name=>'P2_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(234305292675035516)
,p_prompt=>'All Statuses'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(operational_status) d, operational_status r',
'from (',
'  select distinct operational_status',
'  from laouc_locations',
')',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(234305355100035517)
,p_name=>'New'
,p_static_id=>'new'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_COUNTRY,P2_CITY,P2_CATEGORY,P2_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(234305467829035518)
,p_event_id=>wwv_flow_imp.id(234305355100035517)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234313541402070547)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
