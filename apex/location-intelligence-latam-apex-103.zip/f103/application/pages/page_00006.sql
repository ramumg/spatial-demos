prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Distribution Routes'
,p_alias=>'DISTRIBUTION-ROUTES'
,p_step_title=>'Distribution Routes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Fix: Spatial Studio embed requests the MapLibre worker from /ords/api/... (404).',
'// Send it to the Spatial Studio path so the map can load tiles and layers.',
'(function () {',
'  var NativeWorker = window.Worker;',
'  window.Worker = function (url, opts) {',
'    var s = String(url);',
'    if (s.indexOf(''maplibre-gl-worker.js'') !== -1 && s.indexOf(''/spatialstudio/'') === -1) {',
'      url = location.origin + ''/spatialstudio/api/v1/plugins/resource/bundles/maplibre-gl-worker.js'';',
'    }',
'    return new NativeWorker(url, opts);',
'  };',
'  window.Worker.prototype = NativeWorker.prototype;',
'})();// Fix: Spatial Studio embed requests the MapLibre worker from /ords/api/... (404).',
'// Send it to the Spatial Studio path so the map can load tiles and layers.',
'(function () {',
'  var NativeWorker = window.Worker;',
'  window.Worker = function (url, opts) {',
'    var s = String(url);',
'    if (s.indexOf(''maplibre-gl-worker.js'') !== -1 && s.indexOf(''/spatialstudio/'') === -1) {',
'      url = location.origin + ''/spatialstudio/api/v1/plugins/resource/bundles/maplibre-gl-worker.js'';',
'    }',
'    return new NativeWorker(url, opts);',
'  };',
'  window.Worker.prototype = NativeWorker.prototype;',
'})();'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(235658199126764472)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(234283698800962642)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(235659205606767711)
,p_plug_name=>'Routes Map'
,p_static_id=>'mapa-de-rutas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script src="https://g04882e973a17cf-adb26aichicago.adb.us-chicago-1.oraclecloudapps.com/spatialstudio/api/v1/embeddable.js?ex=kobinding"></script>',
'',
'<style>',
'    body {',
'        overflow: auto !important;',
'    }',
'',
'    a:visited {',
'        color: #fff !important;',
'    }',
'</style>',
'',
'<div id="ruta-spatial-studio" style="width:100%; height:62vh; min-height:520px;">',
'  <spatial-studio-project',
'    id="spatial-studio-project-1"',
'    server-url="https://g04882e973a17cf-adb26aichicago.adb.us-chicago-1.oraclecloudapps.com/spatialstudio/"',
'    project-id="ba712973783d1b67a5d90b83c813f45a"',
'    token="REPLACE_WITH_SPATIAL_STUDIO_TOKEN"',
'    project-header="off"',
'    layers-list="on">',
'  </spatial-studio-project>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(235665442585847711)
,p_plug_name=>'New'
,p_static_id=>'new'
,p_title=>'Routes Summary'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    location_name as origen,',
'    city_name || '', '' || country_name as ciudad_origen,',
'    round(drive_distance, 1) as distancia_km,',
'    round(drive_time, 0) as tiempo_min',
'from laouc_locations',
'where route_geom is not null',
'  and drive_distance > 0',
'order by drive_time'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Routes Summary'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(235691504403875111)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>10719993399942301
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(235691709497875113)
,p_db_column_name=>'CIUDAD_ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Origin City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(235691787158875114)
,p_db_column_name=>'DISTANCIA_KM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Distance (km)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(235691556973875112)
,p_db_column_name=>'ORIGEN'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Origin site'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(235691851448875115)
,p_db_column_name=>'TIEMPO_MIN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Time (min)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(235702989139875545)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORIGEN:CIUDAD_ORIGEN:DISTANCIA_KM:TIEMPO_MIN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(235685194006864711)
,p_plug_name=>'Distribution Routes'
,p_static_id=>'new_1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>Distribution Network &amp; Routes to CDMX</h1>',
'<p>See how the network reaches the <strong>CDMX Distribution Center</strong>. The map shows the origin hubs, every site in the network by type (distribution centers, service centers, branches and clients), the area each hub serves (its 3 nearest site'
||'s), the GDL&ndash;CDMX trunk corridor, and the delivery routes Oracle Spatial Studio calculated, each with its distance and estimated drive time.</p>',
'<p><strong>Business question:</strong> Which origin can serve the operation the fastest, and which sites does each hub cover?</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
