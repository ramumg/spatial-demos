prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Location Intelligence LATAM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675741688840605)
,p_plug_name=>'Coverage Rate'
,p_static_id=>'coverage-rate'
,p_title=>'Coverage Rate'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>35
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Coverage Rate'' as card_title,',
' round(100 * sum(case when exists (select 1 from laouc_regions r where sdo_anyinteract(r.geom, l.geom) = ''TRUE'') then 1 else 0 end) / count(*)) || ''%'' as card_text',
'from laouc_locations l'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(117675741689840605)
,p_region_id=>wwv_flow_imp.id(117675741688840605)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(117675741690840605)
,p_card_id=>wwv_flow_imp.id(117675741689840605)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308567455035549)
,p_plug_name=>'From Addresses to Decisions'
,p_static_id=>'de-direcciones-a-decisiones'
,p_title=>'From Addresses to Decisions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Conecta LATAM turns operational addresses into geometries to visualize coverage, find nearby locations and prioritize regional decisions.</p>',
'',
unistr('<p><strong>Demo flow:</strong> Address \2192 Coordinates \2192 Oracle Spatial \2192 Analysis \2192 APEX Map.</p>')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234296250151962733)
,p_plug_name=>'Location Intelligence LATAM'
,p_static_id=>unistr('inteligencia-de-ubicaci\00F3n-latam')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675741691840605)
,p_plug_name=>'Locations by Country'
,p_static_id=>'locations-by-country'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>45
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(117675741692840605)
,p_region_id=>wwv_flow_imp.id(117675741691840605)
,p_chart_type=>'bar'
,p_height=>'320'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'top'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(117675741694840605)
,p_chart_id=>wwv_flow_imp.id(117675741692840605)
,p_static_id=>'coverage-gap'
,p_seq=>20
,p_name=>'Coverage gap'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.country_name as label, count(*) as value',
'from laouc_locations l',
'where not exists (select 1 from laouc_regions r where sdo_anyinteract(r.geom, l.geom) = ''TRUE'')',
'group by l.country_name',
'order by 1'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#D62828'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(117675741693840605)
,p_chart_id=>wwv_flow_imp.id(117675741692840605)
,p_static_id=>'inside-coverage'
,p_seq=>10
,p_name=>'Inside coverage'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.country_name as label, count(*) as value',
'from laouc_locations l',
'where exists (select 1 from laouc_regions r where sdo_anyinteract(r.geom, l.geom) = ''TRUE'')',
'group by l.country_name',
'order by 1'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#2E9E44'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(117675741695840605)
,p_chart_id=>wwv_flow_imp.id(117675741692840605)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(117675741696840605)
,p_chart_id=>wwv_flow_imp.id(117675741692840605)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Locations'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_step=>1
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234699810285371315)
,p_plug_name=>'Map'
,p_static_id=>'map'
,p_title=>'LATAM Operations Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(234699896486371316)
,p_region_id=>wwv_flow_imp.id(234699810285371315)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(130885667971975801)
,p_map_region_id=>wwv_flow_imp.id(234699896486371316)
,p_name=>'Branches'
,p_static_id=>'branches'
,p_layer_type=>'POINT'
,p_display_sequence=>11
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       category,',
'       ''Branch'' as site_type,',
'       latitude,',
'       longitude',
'from laouc_locations',
'where category = ''SUCURSAL'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#B8860B'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(130890651833975601)
,p_map_region_id=>wwv_flow_imp.id(234699896486371316)
,p_name=>'Clients'
,p_static_id=>'clients'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       category,',
'       ''Client'' as site_type,',
'       latitude,',
'       longitude',
'from laouc_locations',
'where category = ''CLIENTE'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#1E88E5'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(130685687874976801)
,p_map_region_id=>wwv_flow_imp.id(234699896486371316)
,p_name=>'Service Centers'
,p_static_id=>'service-centers'
,p_layer_type=>'POINT'
,p_display_sequence=>12
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       category,',
'       ''Service center'' as site_type,',
'       latitude,',
'       longitude',
'from laouc_locations',
'where category = ''CENTRO_SERVICIO'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#7B1FA2'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234700035129371318)
,p_map_region_id=>wwv_flow_imp.id(234699896486371316)
,p_name=>'Geocoded Locations'
,p_static_id=>'ubicaciones-geocodificadas'
,p_layer_type=>'POINT'
,p_display_sequence=>50
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select request_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       street_address,',
'       latitude,',
'       longitude',
'from laouc_geocode_requests',
'where geocode_status = ''GEOCODIFICADA'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'REQUEST_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#db6600'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&LOCATION_NAME.<br>&STREET_ADDRESS.<br>',
'&CITY_NAME., &COUNTRY_NAME.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(234699992076371317)
,p_map_region_id=>wwv_flow_imp.id(234699896486371316)
,p_name=>'Distribution Centers'
,p_static_id=>'ubicaciones-operativas'
,p_layer_type=>'POINT'
,p_display_sequence=>13
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location_id,',
'       location_name,',
'       city_name,',
'       country_name,',
'       category,',
'       ''Distribution center'' as site_type,',
'       latitude,',
'       longitude',
'from laouc_locations',
'where category = ''CENTRO_DISTRIBUCION'''))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'#2E7D32'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
unistr('&SITE_TYPE. \00B7 &CITY_NAME., &COUNTRY_NAME.')))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308138074035545)
,p_plug_name=>'Countries with Operations'
,p_static_id=>'paises-con-operacion'
,p_title=>'Countries with Operations'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
' ''Countries with Operations'' as card_title,',
'    count(distinct country_name) as card_text',
'from laouc_locations'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(234308268807035546)
,p_region_id=>wwv_flow_imp.id(234308138074035545)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(234699520612371313)
,p_card_id=>wwv_flow_imp.id(234308268807035546)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308000354035543)
,p_plug_name=>'Operational Locations'
,p_static_id=>'ubicaciones-operativas'
,p_title=>'Operational Locations'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Operational Locations'' as card_title,',
'       count(*) as card_text',
'from laouc_locations'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(234308026357035544)
,p_region_id=>wwv_flow_imp.id(234308000354035543)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(234699471712371312)
,p_card_id=>wwv_flow_imp.id(234308026357035544)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308333313035547)
,p_plug_name=>'Coverage Zones'
,p_static_id=>'zona-de-cobertura'
,p_title=>'Coverage Zones'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
' ''Coverage Zones'' as card_title,',
'    count(*) as card_text',
'from laouc_regions'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(234308444918035548)
,p_region_id=>wwv_flow_imp.id(234308333313035547)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(234699661769371314)
,p_card_id=>wwv_flow_imp.id(234308444918035548)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(234699371705371311)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset Demo from Navigation Bar'
,p_static_id=>'reiniciar-demo-desde-navigation-bar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from laouc_geocode_requests;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'RESET_APP'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>9727860701438501
);
wwv_flow_imp.component_end;
end;
/
