prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Coverage Gaps'
,p_alias=>'COVERAGE-GAPS'
,p_step_title=>'Coverage Gaps'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742591840605)
,p_plug_name=>'Coverage Gap Map'
,p_static_id=>'coverage-gap-map'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(117675742592840605)
,p_region_id=>wwv_flow_imp.id(117675742591840605)
,p_height=>560
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(117675742595840605)
,p_map_region_id=>wwv_flow_imp.id(117675742592840605)
,p_name=>'Coverage Gaps'
,p_static_id=>'coverage-gaps'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with pts as (',
' select ''S'' || location_id as pt_key, location_name, city_name, country_name, geom',
' from laouc_locations',
' union all',
' select ''G'' || request_id, location_name, city_name, country_name, gc_geometry',
' from laouc_geocode_requests',
' where geocode_status = ''GEOCODIFICADA''',
'), d as (',
' select p.pt_key, p.location_name, p.city_name, p.country_name, p.geom, r.region_name,',
' sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'') as dist,',
' row_number() over (partition by p.pt_key order by sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'')) as rn',
' from pts p cross join laouc_regions r',
')',
'select pt_key, location_name, city_name, country_name, geom,',
' replace(region_name, ''Cobertura '', '''') || '' zone'' as nearest_zone,',
' round(dist, 1) as dist_km',
'from d where rn = 1 and dist > 0'))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'PT_KEY'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#d62828'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
'&CITY_NAME., &COUNTRY_NAME.<br>',
'&DIST_KM. km from &NEAREST_ZONE.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(117675742593840605)
,p_map_region_id=>wwv_flow_imp.id(117675742592840605)
,p_name=>'Coverage Zones'
,p_static_id=>'coverage-zones'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'LAOUC_REGIONS'
,p_include_rowid_column=>false
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_stroke_color=>'#1f5fa8'
,p_fill_color=>'#5b9bd5'
,p_fill_color_is_spectrum=>false
,p_fill_opacity_subst=>'.35'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'REGION_NAME'
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(117675742594840605)
,p_map_region_id=>wwv_flow_imp.id(117675742592840605)
,p_name=>'Covered Sites'
,p_static_id=>'covered-sites'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with pts as (',
' select ''S'' || location_id as pt_key, location_name, city_name, country_name, geom',
' from laouc_locations',
' union all',
' select ''G'' || request_id, location_name, city_name, country_name, gc_geometry',
' from laouc_geocode_requests',
' where geocode_status = ''GEOCODIFICADA''',
'), d as (',
' select p.pt_key, p.location_name, p.city_name, p.country_name, p.geom, r.region_name,',
' sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'') as dist,',
' row_number() over (partition by p.pt_key order by sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'')) as rn',
' from pts p cross join laouc_regions r',
')',
'select pt_key, location_name, city_name, country_name, geom,',
' replace(region_name, ''Cobertura '', '''') || '' zone'' as nearest_zone,',
' round(dist, 1) as dist_km',
'from d where rn = 1 and dist = 0'))
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'PT_KEY'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#2e9e44'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
'&CITY_NAME., &COUNTRY_NAME.<br>Inside &NEAREST_ZONE.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742588840605)
,p_plug_name=>'Coverage KPIs'
,p_static_id=>'coverage-kpis'
,p_title=>'Coverage KPIs'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with pts as (',
' select ''S'' || location_id as pt_key, location_name, city_name, country_name, geom',
' from laouc_locations',
' union all',
' select ''G'' || request_id, location_name, city_name, country_name, gc_geometry',
' from laouc_geocode_requests',
' where geocode_status = ''GEOCODIFICADA''',
'), d as (',
' select p.pt_key, p.location_name, p.city_name, p.country_name, p.geom, r.region_name,',
' sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'') as dist,',
' row_number() over (partition by p.pt_key order by sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'')) as rn',
' from pts p cross join laouc_regions r',
')',
'select card_title, card_text from (',
' select ''Sites analyzed'' as card_title, to_char(count(*)) as card_text, 1 as ord from d where rn = 1',
' union all',
' select ''Inside a coverage zone'', to_char(sum(case when dist = 0 then 1 else 0 end)), 2 from d where rn = 1',
' union all',
' select ''Coverage gaps'', to_char(sum(case when dist > 0 then 1 else 0 end)), 3 from d where rn = 1',
' union all',
' select ''Coverage rate'', round(100 * sum(case when dist = 0 then 1 else 0 end) / count(*)) || ''%'', 4 from d where rn = 1',
')',
'order by ord'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(117675742589840605)
,p_region_id=>wwv_flow_imp.id(117675742588840605)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(117675742596840605)
,p_name=>'Sites Outside Coverage'
,p_static_id=>'sites-outside-coverage'
,p_template=>4073835273271169698
,p_display_sequence=>30
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with pts as (',
' select ''S'' || location_id as pt_key, location_name, city_name, country_name, geom',
' from laouc_locations',
' union all',
' select ''G'' || request_id, location_name, city_name, country_name, gc_geometry',
' from laouc_geocode_requests',
' where geocode_status = ''GEOCODIFICADA''',
'), d as (',
' select p.pt_key, p.location_name, p.city_name, p.country_name, p.geom, r.region_name,',
' sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'') as dist,',
' row_number() over (partition by p.pt_key order by sdo_geom.sdo_distance(r.geom, p.geom, 0.005, ''unit=KM'')) as rn',
' from pts p cross join laouc_regions r',
')',
'select location_name as site,',
' city_name || '', '' || country_name as city_country,',
' replace(region_name, ''Cobertura '', '''') || '' zone'' as nearest_zone,',
' round(dist, 1) as distance_km,',
' case when dist <= 10 then ''Quick win: extend the existing zone''',
' when dist <= 500 then ''Candidate for a new coverage zone''',
' else ''Strategic expansion'' end as recommendation',
'from d',
'where rn = 1 and dist > 0',
'order by dist'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Every site is inside a coverage zone.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675742598840605)
,p_query_column_id=>2
,p_column_alias=>'CITY_COUNTRY'
,p_column_display_sequence=>20
,p_column_heading=>'City, Country'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675742600840605)
,p_query_column_id=>4
,p_column_alias=>'DISTANCE_KM'
,p_column_display_sequence=>40
,p_column_heading=>'Distance to Zone (km)'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675742599840605)
,p_query_column_id=>3
,p_column_alias=>'NEAREST_ZONE'
,p_column_display_sequence=>30
,p_column_heading=>'Nearest Zone'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675742601840605)
,p_query_column_id=>5
,p_column_alias=>'RECOMMENDATION'
,p_column_display_sequence=>50
,p_column_heading=>'Recommendation'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117675742597840605)
,p_query_column_id=>1
,p_column_alias=>'SITE'
,p_column_display_sequence=>10
,p_column_heading=>'Site'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742590840605)
,p_plug_name=>'Why it matters'
,p_static_id=>'why-it-matters'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>15
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Where should we expand next?</strong> Oracle Spatial measures how far each site is from the nearest coverage zone ',
'(<code>SDO_GEOM.SDO_DISTANCE</code>) and flags the ones outside every zone (<code>SDO_ANYINTERACT</code>). ',
'Sites only a few km away are quick wins: extend the existing zone. Distant clusters are candidates for a new zone.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
