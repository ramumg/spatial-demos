prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Ask the Map'
,p_alias=>'ASK-THE-MAP'
,p_step_title=>'Ask the Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742695840605)
,p_plug_name=>'Answer'
,p_static_id=>'answer'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<div style="font-size:1.1rem;line-height:1.6;white-space:pre-line">&P11_ANSWER.</div>'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P11_ANSWER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742688840605)
,p_plug_name=>'Ask a Question'
,p_static_id=>'ask-a-question'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742700840605)
,p_plug_name=>'Generated SQL (Select AI)'
,p_static_id=>'generated-sql'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Oracle Autonomous Database <strong>Select AI</strong> translated the question into this SQL:</p>',
'<pre style="white-space:pre-wrap;font-size:.8rem;margin:0">&P11_SQL.</pre>'))
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P11_SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117675742696840605)
,p_plug_name=>'Results on the Map'
,p_static_id=>'results-on-the-map'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P11_IDS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(117675742697840605)
,p_region_id=>wwv_flow_imp.id(117675742696840605)
,p_height=>480
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(117675742698840605)
,p_map_region_id=>wwv_flow_imp.id(117675742697840605)
,p_name=>'Coverage Zones'
,p_static_id=>'coverage-zones'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'LAOUC_REGIONS'
,p_include_rowid_column=>false
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_stroke_color=>'#1f5fa8'
,p_fill_color=>'#5b9bd5'
,p_fill_color_is_spectrum=>false
,p_fill_opacity_subst=>'.35'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'REGION_NAME'
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(117675742699840605)
,p_map_region_id=>wwv_flow_imp.id(117675742697840605)
,p_name=>'Matching Locations'
,p_static_id=>'matching-locations'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location_id, location_name, city_name, country_name, category, geom',
'from laouc_locations',
'where instr('':'' || :P11_IDS || '':'', '':'' || location_id || '':'') > 0'))
,p_items_to_submit=>'P11_IDS'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color=>'#e67e22'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME.</strong><br>',
'&CITY_NAME., &COUNTRY_NAME.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(117675742694840605)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_button_name=>'ASK'
,p_static_id=>'ask'
,p_button_action=>'SUBMIT'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask the Map'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(117675742701840605)
,p_branch_name=>'Back to Ask the Map'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117675742693840605)
,p_name=>'P11_ANSWER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117675742691840605)
,p_name=>'P11_IDS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117675742690840605)
,p_name=>'P11_QUESTION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_prompt=>'Or type your own question'
,p_placeholder=>'e.g. Which clients are closest to a distribution center?'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>1000
,p_cHeight=>3
,p_field_template=>1610598304472262251
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117675742689840605)
,p_name=>'P11_SAMPLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_prompt=>'Try a sample question'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select q as d, q as r from (',
' select 1 as ord, ''Which locations are not covered by any coverage zone?'' as q from dual union all',
' select 2 as ord, ''How many locations are there in each country?'' as q from dual union all',
' select 3 as ord, ''List all distribution centers and service centers.'' as q from dual union all',
' select 4 as ord, ''Which clients are still pending activation?'' as q from dual union all',
' select 5 as ord, ''Which branches are more than 300 km from the nearest distribution center?'' as q from dual',
')',
'order by ord'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Choose a sample question --'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117675742692840605)
,p_name=>'P11_SQL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(117675742688840605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117675742702840605)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ask Select AI'
,p_static_id=>'ask-select-ai'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_ctx varchar2(2000) := ''Always return the LOCATION_ID and LOCATION_NAME columns of LAOUC_LOCATIONS when the question is about locations. Data values are in Spanish: CATEGORY '' ||',
'    ''is one of CENTRO_DISTRIBUCION (distribution center), CENTRO_SERVICIO (service center), SUCURSAL (branch), CLIENTE (client); OPERATIONAL_STATUS is ACTI'' ||',
'    ''VA (active) or PENDIENTE (pending). LAOUC_REGIONS.GEOM are coverage zone polygons; a location is covered when SDO_ANYINTERACT(r.GEOM, l.GEOM) = ''''TRUE'''''' ||',
'    ''. Distances in km: SDO_GEOM.SDO_DISTANCE(a.GEOM, b.GEOM, 0.005, ''''unit=KM''''). Answer in English. Question: '';',
'  l_q    varchar2(4000) := trim(coalesce(:P11_QUESTION, :P11_SAMPLE));',
'  l_sql  clob;',
'  l_cur  integer;',
'  l_cnt  integer;',
'  l_desc dbms_sql.desc_tab2;',
'  l_col  integer;',
'  l_val  varchar2(4000);',
'  l_ids  varchar2(4000);',
'  l_rows integer;',
'begin',
'  :P11_ANSWER := null;',
'  :P11_SQL := null;',
'  :P11_IDS := null;',
'  if l_q is null then',
'    return;',
'  end if;',
'  :P11_QUESTION := l_q;',
'  l_sql := dbms_cloud_ai.generate(prompt => l_ctx || l_q, profile_name => ''GENAI_PROFILE'', action => ''showsql'');',
'  :P11_SQL := dbms_lob.substr(l_sql, 4000, 1);',
'  :P11_ANSWER := dbms_lob.substr(dbms_cloud_ai.generate(prompt => l_ctx || l_q, profile_name => ''GENAI_PROFILE'', action => ''narrate''), 4000, 1);',
'  -- run the generated query (read-only SELECT only) to plot the matching locations',
'  if regexp_like(l_sql, ''^\s*(select|with)\s'', ''in'') and instr(l_sql, '';'') = 0 then',
'    begin',
'      l_cur := dbms_sql.open_cursor;',
'      dbms_sql.parse(l_cur, l_sql, dbms_sql.native);',
'      dbms_sql.describe_columns2(l_cur, l_cnt, l_desc);',
'      for i in 1 .. l_cnt loop',
'        if regexp_replace(upper(l_desc(i).col_name), ''[^A-Z]'') = ''LOCATIONID'' then',
'          l_col := i;',
'          exit;',
'        end if;',
'      end loop;',
'      if l_col is not null then',
'        dbms_sql.define_column(l_cur, l_col, l_val, 4000);',
'        l_rows := dbms_sql.execute(l_cur);',
'        while dbms_sql.fetch_rows(l_cur) > 0 and nvl(length(l_ids), 0) < 3900 loop',
'          dbms_sql.column_value(l_cur, l_col, l_val);',
'          l_ids := l_ids || case when l_ids is not null then '':'' end || l_val;',
'        end loop;',
'      end if;',
'      dbms_sql.close_cursor(l_cur);',
'    exception',
'      when others then',
'        if dbms_sql.is_open(l_cur) then',
'          dbms_sql.close_cursor(l_cur);',
'        end if;',
'    end;',
'  end if;',
'  :P11_IDS := l_ids;',
'exception',
'  when others then',
'    :P11_ANSWER := ''Select AI could not answer this question: '' || sqlerrm;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(117675742694840605)
,p_internal_uid=>117675742702840605
);
wwv_flow_imp.component_end;
end;
/
