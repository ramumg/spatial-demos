prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>8885641780266032
,p_default_application_id=>103
,p_default_id_offset=>116685741587840605
,p_default_owner=>'LAOUC2026'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Geocoding'
,p_alias=>'GEOCODING'
,p_step_title=>'Geocoding'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234693118176016840)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(234283698800962642)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234700206317371319)
,p_plug_name=>'New'
,p_static_id=>'new'
,p_title=>unistr('Address \2192 Geometry \2192 Map')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter an operational address. Autonomous Database geocodes it and stores it',
'as an <strong>SDO_GEOMETRY</strong> that can be used immediately in maps and',
'spatial queries.</p>',
'',
'<p><strong>During the demo:</strong> the new point will appear on Home and on the',
'Locations Map with the geocoding color.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(234700271676371320)
,p_name=>'New'
,p_static_id=>'new_1'
,p_title=>'Latest Geocoded Result'
,p_template=>4073835273271169698
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'    select location_name                         as ubicacion,',
'           street_address                        as direccion,',
'           city_name || '', '' || country_name     as ciudad_pais,',
'           round(latitude, 6)                    as latitud,',
'           round(longitude, 6)                   as longitud,',
'           geocode_status                        as estado',
'    from laouc_geocode_requests',
'    where geocode_status = ''GEOCODIFICADA''',
'    order by request_id desc',
')',
'where rownum = 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700585619371323)
,p_query_column_id=>3
,p_column_alias=>'CIUDAD_PAIS'
,p_column_display_sequence=>30
,p_column_heading=>'City, Country'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700478615371322)
,p_query_column_id=>2
,p_column_alias=>'DIRECCION'
,p_column_display_sequence=>20
,p_column_heading=>'Address'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700900589371326)
,p_query_column_id=>6
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>60
,p_column_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700688633371324)
,p_query_column_id=>4
,p_column_alias=>'LATITUD'
,p_column_display_sequence=>40
,p_column_heading=>'Latitude'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700717518371325)
,p_query_column_id=>5
,p_column_alias=>'LONGITUD'
,p_column_display_sequence=>50
,p_column_heading=>'Longitude'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(234700325488371321)
,p_query_column_id=>1
,p_column_alias=>'UBICACION'
,p_column_display_sequence=>10
,p_column_heading=>'Location'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308639740035550)
,p_plug_name=>'New Location'
,p_static_id=>unistr('nueva-ubicaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234308796525035551)
,p_plug_name=>'Register an Address'
,p_static_id=>'registra-de-direccion'
,p_title=>'Register an address to send it to the geocoding process.'
,p_parent_plug_id=>wwv_flow_imp.id(234308639740035550)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(234309426766035558)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_button_name=>'SAVE_LOCATION'
,p_static_id=>'save-location'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Geocode and Save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234309057879035554)
,p_name=>'P3_CIUDAD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'City'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234309217304035556)
,p_name=>'P3_DIRECCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'Address'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234308923523035553)
,p_name=>'P3_LATITUD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'Latitude'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234309398195035557)
,p_name=>'P3_LONGITUD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'Longitude'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234308834509035552)
,p_name=>'P3_NOMBRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'Location Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234309145555035555)
,p_name=>'P3_PAIS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(234308796525035551)
,p_prompt=>'Country'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select country_name d, country_name r',
'from (',
'    select distinct country_name',
'    from laouc_locations',
')',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(234309542562035559)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Geocoding Request'
,p_static_id=>unistr('guardar-solicitud-de-geocodificaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_geom mdsys.sdo_geometry;',
'    l_country_code varchar2(2);',
'begin',
'    l_country_code := case :P3_PAIS',
unistr('        when ''M\00E9xico''    then ''MX'''),
'        when ''Guatemala'' then ''GT''',
'        when ''Brasil''    then ''BR''',
'        when ''Uruguay''   then ''UY''',
'        when ''Argentina'' then ''AR''',
'        when ''Paraguay''  then ''PY''',
'    end;',
'',
'    l_geom := sdo_gcdr.eloc_geocode_as_geom(',
'        :P3_DIRECCION,',
'        :P3_CIUDAD,',
'        null,',
'        null,',
'        l_country_code',
'    );',
'',
'    if l_geom is null then',
'        raise_application_error(',
'            -20001,',
' ''No location was found for this address. Please check the address, city and country.''',
'        );',
'    end if;',
'',
'    insert into laouc_geocode_requests (',
'        location_name,',
'        country_name,',
'        city_name,',
'        street_address,',
'        latitude,',
'        longitude,',
'        gc_geometry,',
'        geocode_status,',
'        processed_at',
'    ) values (',
'        :P3_NOMBRE,',
'        :P3_PAIS,',
'        :P3_CIUDAD,',
'        :P3_DIRECCION,',
'        l_geom.sdo_point.y,',
'        l_geom.sdo_point.x,',
'        l_geom,',
'        ''GEOCODIFICADA'',',
'        systimestamp',
'    );',
'',
'    :P3_LATITUD := l_geom.sdo_point.y;',
'    :P3_LONGITUD := l_geom.sdo_point.x;',
'',
'    apex_application.g_print_success_message :=',
' ''Address geocoded and saved successfully.'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(234309426766035558)
,p_internal_uid=>9338031558102749
);
wwv_flow_imp.component_end;
end;
/
