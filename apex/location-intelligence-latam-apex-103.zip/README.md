# Location Intelligence LATAM (Oracle APEX app 103)

Oracle APEX 26.1 application export, split into one file per component.

## Install

1. In APEX, go to **App Builder → Import**, and upload a ZIP of the `f103` folder.
   Or run `@f103/install.sql` from SQLcl while connected to the parsing schema.
2. The database objects the app uses (tables, views, spatial data) are **not** in this repo
   and must exist in the target schema before you install.

## Configuration: Spatial Studio token

The Spatial Studio embed token was removed before publishing. After you import the app, replace
`REPLACE_WITH_SPATIAL_STUDIO_TOKEN` in:

- Page 6 (Routes): the `spatial-studio-project` region
- Shared Components → Static Application Files → `spatial-routes.html`

Also update `server-url` and `project-id` to match your own Spatial Studio instance.
Generate a read-only embed token in Spatial Studio (Project → Share → Token).
